# Wolf Wolf Dog v0.1

Protótipo 2D para navegador, feito para teste pelo celular.

## O que já funciona
- Menu inicial
- Mapa Canil Central
- Personagem jogável
- Movimento por teclado e toque
- 4 bots
- 5 tarefas
- Barra global de tarefas
- Reunião de emergência simulada
- HUD mobile
- Vitória básica ao completar 5 tarefas

## Limitação desta versão
É um protótipo local/offline. Ainda não possui multiplayer real, lobby, funções secretas completas, sabotagens, eliminação ou votação online.

## Como testar
Abra `index.html` em um navegador com internet, pois o Phaser é carregado por CDN.

Para desenvolvimento local com Vite/TypeScript, esta versão pode ser migrada para a estrutura Phaser + TypeScript + Vite.
